<?php
	include("header.php");
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12" id="welcome">
				<div class="col-lg-12">
					<h2 class="text-center">STEP 1: Read Your Meter</h2>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<p  class="text-center"><label>a) This is how your meter looks like:</label></p>
					<div class="thumbnail" style="border:0px;">
						<img src="images/meter1.jpg" height="200px">
					</div>
				</div>
				<div class="col-lg-6">
					<p  class="text-center"><label>b) Enter your readings below and click 'calculate bill'</label></p>
					<div class="form-group col-lg-12">
						<input type="text" class="form-control" name="" placeholder="number of kilolitres used(reading in black)">
					</div>
					<div class="form-group col-lg-12">
						<input type="text" class="form-control" name="" placeholder="number of litres used(reading in red)">
					</div>
					<div class="form-group col-lg-12">
						<input type="text" class="form-control" name="" placeholder="VAT" value="">
					</div>
					<div class="col-lg-12" style="padding: 30px;">
						<button class="btn btn-primary" style="margin-left: 35%;">CALCULATE BILL</button>
					</div>
					<div class="col-lg-12" id="results">
						<h4></h4>
					</div>
			</div>
			
			</div>
			<div class="col-lg-12">
				<div class="progress">
						<div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%">
					</div>
				</div> 
				<label>You are 50% done</label>
			</div>
			<div class="col-lg-12" style="margin-bottom: 2S%;">
					<div class="col-lg-5">
					</div>
					<div class="col-lg-4">
						<a href="payment.php"><button class="btn btn-lg btn-primary">NEXT <span class="glyphicon glyphicon-arrow-right"></span></button></a>
					</div>
				</div>
		</div>
	</div>
	 <?php
            include("footer.php");
            ?>
<?php session_start(); ?>
<?php
    include('dbconnect.php');
    //define authentication error
    $err='';
    $password=$name="";
    
    if($_SERVER["REQUEST_METHOD"]=='POST'){
        $password=$_POST['password'];
        $name=mysqli_real_escape_string($conn,$_POST['name']);
        $login="SELECT name,password FROM customers WHERE name='$name' AND password='$password'";
        $run_login=mysqli_query($conn,$login);
        $check_customer=mysqli_num_rows($run_login);
        
        $qry="SELECT * FROM customers WHERE name='$name' AND password='$password'";
        $exec=mysqli_query($conn,$qry);
        while ($result=mysqli_fetch_array($exec)) {
            $customer_id=$result['customer_id'];
        }
            if($check_customer==0){
                $err= "Invalid credentials.Try again";
            }
                elseif($check_customer==1){
                    $_SESSION["customer_name"]=$name;
                    $_SESSION["customer_id"]=$customer_id;
                    header("location: cart.php?u=".$name."&uid=".$customer_id);
/*
                        //check if  page is redirecting from checkout.php
                     /*   if(isset($_SESSION['checkout_to_login_message'])){
                            header("location:checkout.php");
                            
                        }
                        else
                        {
                            header("location:index.php");
                        }
                        */
                         if(isset($_SESSION['cartmsg'])){
                            header("location:cart.php");
                            
                        }
                        else
                        {
                            header("location:index.php");
                        }
                }
                    elseif ($check_customer>1) {
                        $err="There seems to be a problem with your account. You have to confirm that it belongs to you before you proceed.";
                    }
    }
     
      
include("header.php");
?>
        <div class="container">
            <div class="row">
                <div class="col-lg-12" id="log">
                    <div class="col-lg-6">
                        <div class="thumbnail">
                            <img src="images/icon.jpeg" alt="image not found">
                        </div>
                    </div>
                    <div id="login" class="col-lg-6" style="">
                        <!--check if  page is redirecting from checkout.php-->
                        <?php
                            if(isset($_SESSION['checkout_to_login_message'])){
                         ?>
                                    <div class="alert alert-danger"><p><strong><?php echo $_SESSION['checkout_to_login_message'];?></strong></p></div>
                        <?php
                         }
                        ?>
                          <?php
                            if(isset($_SESSION['cartmsg'])){
                         ?>
                                    <div class="alert alert-danger"><p><strong><?php echo $_SESSION['cartmsg'];?></strong></p></div>
                        <?php
                         }
                        ?>
                        <!-- check if page is redirecting from signup page-->
                        <?php
                            if(isset($_SESSION['signup_to_login_message'])){
                        ?>
                                <div class="alert alert-info"><p><strong><?php echo $_SESSION['signup_to_login_message'];?></strong></p></div>
                        <?php
                            unset($_SESSION['signup_to_login_message']);
                            }
                        ?>

                        <!--dislay authentication errors-->
                        <?php 
                            if(!empty($err) && $err!==""){  //check whether there are authentication errors
                         ?>
                                <div class="alert alert-danger">
                                    <?php
                                        echo $err;
                                     ?>
                                </div>
                        <?php
                            }
                         ?>
                         <h3 class="text-center">Login to your account</h3>
                         <form class='' action="" method="POST" id
                            login>
                            <div class="form-group">
                                <input type="name" class="form-control" id="name" name="name" value="<?php echo $name;?>" placeholder="username or email">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="pw" name="password" placeholder="password">
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" value="">Remember me</label>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-sm" name="login" style="color: white;background-color: #6d07da;margin-left: 45%">log in</button>
                            </div>           
                        </form>   
                        <h4 class="text-center">Or Login in with:</h4>
                            <ul id='social-login' style="list-style-type: none; font-size: 30px; margin-left: 15%">
                                <li style="display: inline; "><a href="#"><span class="fa fa-facebook" style=""></span> </a></li>
                                <li style="display: inline; "><a href="#"><span class="fa fa-twitter" style=""></span> </a></li>
                                <li style="display: inline; "><a href="#"><span class="fa fa-google-plus" style="color: #f2190e ;"></span> </a></li>
                             </ul>
                       <h5 class="text-center"><label> Not signed up? <a href="signup.php" class="">Create an account</a></label></h5>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php
            include("footer.php");
            ?>

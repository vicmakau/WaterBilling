<?php
	include("header.php");
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12" id="welcome">
				<div class="col-lg-12">
					<h2 class="text-center">STEP 3:Now Let's pay your bill</h2>
						<p  class="text-center"><label>It's fast, secure and easy.</label></p>
				</div>
				<div class="col-lg-12">
					<div class="col-lg-6">
						<h3>Credit Card</h3>
							<form class='' action="" method="POST" >
			                    <div class="form-group col-lg-12">
			                    	<label for="name">Name:</label>
			                        <input type="text" class="form-control" id="name" name="name" value="<?php /*echo $name*/;?>" placeholder="Enter the name on the card">
			                    </div>
			                    <div class="form-group col-lg-12">
			                    	<label for="accno">Account Number:</label>
			                        <input type="text" class="form-control" id="accno" name="accno" value="<?php /*echo $name*/;?>" placeholder="enter the account number">
			                    </div>
			                    <div class="form-group col-lg-6">
			                    	<label for="expDate">Card Expiry Date:</label>
			                        <input type="date" class="form-control" id="expDate" name="expDate" value="<?php /*echo $name*/;?>" placeholder="choose expiry date of the card">
			                    </div>
			                    <div class="form-group col-lg-6">
			                    	<label for="secCode">Security Code:</label>
			                        <input type="text" class="form-control" id="secCode" name="secCode" value="<?php /*echo $name*/;?>" placeholder="enter the 3-digit number at the back of the card">
			                    </div>
			                    <label for="bill">Amount:</label>
			                    <div class="form-group col-lg-12">
			                        <input type="text" class="form-control" id="bill" name="bill" value="<?php /*echo $name*/;?>" placeholder="Amount to be deducted" value="">
			                    </div>
			                    <div class="form-group">
		                        	<button type="submit" class="btn btn-sm btn-primary" name="card_pay" style="color: white; margin-left: 40%">Pay Now</button>
		                    	</div>    
					</div>
					<div class="col-lg-6" id="mpesa_pay">
						<h3>M-Pesa</h3>
						<p class="text-center"><label>Follow the following steps to pay via M-Pesa</label></p>
						<ol>
							<li>Go to your M-Pesa menu</li>
							<li>Select Lipa na M-Pesa</li>
							<li>Select Paybill</li>
							<li>Enter ****** as the Business Number</li>
							<li>Enter your Meter Number as the Account Number</li>
							<li>Enter your bill of Kshs. **** as Amount</li>
							<li>Enter your M-Pesa PIN and Click 'OK'</li>
							<li>Enter the Transaction Code below:</li>
						</ol>
						<form class='' action="" method="POST" >
		                    <div class="form-group col-lg-12">
		                    	<label for="name">M-Pesa Transaction Code:</label>
		                        <input type="text" class="form-control" id="mpesaCode" name="mpesaCode" value="<?php /*echo $name*/;?>" placeholder="Enter the transaction code">
		                    </div>
		                    <div class="form-group">
	                        	<button type="submit" class="btn btn-sm btn-primary" name="mpesa_pay" style="color: white; margin-left: 40%">Pay Now</button>
	                    	</div> 
		                </form>
					</div>
				</div>
			</div>
		</div>
	</div>
	 <?php
            include("footer.php");
            ?>
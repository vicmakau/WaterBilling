		<footer>
			<div class="container-fluid" style="">
				<div class="row">
					<div class="col-lg-12">
						<div class="col-lg-4">
							<h4 class="text-center">WATER BILLING SYSTEM</h4>
							<h5> Te iusto aliquip volutpat sed. Ne sed dicant definitiones interpretaris, his an suscipit ponderum, vim adversarium deterruisset at. Possim iuvaret prodesset et sea, convenire philosophia vim ut. Dicant detracto eu eos, ne elitr convenire eum. At eros putant qui, vis quidam utamur expetendis ne.</h5>		
						</div>
						<div class="col-lg-4">
							<h4 class="text-center">CONTACT US</h4>
							<p><span class="glyphicon glyphicon-envelope"> customercare@billing.com</span></p>
							<p><span class="glyphicon glyphicon-earphone"> +254 712 345 678</span></p>
							<p><span class="glyphicon glyphicon-location"> Nairobi Water Billing,Westlands, Nairobi</span></p>
							<p><span class="glyphicon glyphicon-envelope"> customercare@billing.com</span></p>
						</div>
						<div class="col-lg-4">
							<h4 class="text-center">CONNECT WITH US</h4>

							<ul style="list-style-type: none; ">

								<li><a href="#"><span class="fa fa-facebook" style="color:blue;font-size: 30px"></span> &nbsp;&nbsp;&nbsp;Water Billing</a></li>

								<li><a href="#"><span class="fa fa-twitter" style="color: #3ca9e4;  font-size: 30px;"></span>&nbsp;&nbsp;&nbsp; @water_billing</a></li>

								<li><a href="#"><span class="fa fa-instagram" style="color:#f017a4;font-size: 30px;"></span> &nbsp;&nbsp;&nbsp; @waterBilling</a></li>

							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</body>
</html>
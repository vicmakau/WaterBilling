<?php
	include("dbconnect.php");
	include("header.php");
?>

	
		<div class="container">
		    <div class="row">
		        <div class="col-lg-12" id="account">
		            <div id="signup" class="col-lg-6" style="">
		               
		                 <h3 class="text-center">Create an account today!</h3>
		                  <h4 class="text-center">Signup with:</h4>

		                    <ul id='social-signup' style="list-style-type: none; font-size: 30px; margin-left: 15%">
		                        <li style="display: inline; "><a href="#"><span class="fa fa-facebook" style=""></span> </a></li>
		                        <li style="display: inline; "><a href="#"><span class="fa fa-twitter" style=" ;"></span> </a></li>
		                        <li style="display: inline; "><a href="#"><span class="fa fa-google-plus" style="color: #f2190e ;"></span> </a></li>
		                     </ul>

		                     <h4 class="text-center"><emp>OR</emp></h4>

		                 <form class='' action="" method="POST" >
		                    <div class="form-group col-lg-6">
		                        <input type="text" class="form-control" id="fname" name="fname" value="<?php /*echo $name*/;?>" placeholder="enter your first legal name">
		                    </div>
		                    <div class="form-group col-lg-6">
		                        <input type="text" class="form-control" id="lname" name="lname" value="<?php /*echo $name*/;?>" placeholder="enter your last legal name">
		                    </div>
		                    <div class="form-group col-lg-12">
		                        <input type="text" class="form-control" id="uname" name="uname" value="<?php /*echo $name*/;?>" placeholder="choose a username">
		                    </div>
		                    <div class="form-group col-lg-6">
		                        <input type="text" class="form-control" id="idno" name="idno" value="<?php /*echo $name*/;?>" placeholder="enter your national ID number">
		                    </div>
		                    <div class="form-group col-lg-6">
		                        <input type="text" class="form-control" id="phone" name="phone" value="<?php /*echo $name*/;?>" placeholder="enter your active phone number">
		                    </div>
		                    <div class="form-group col-lg-12">
		                        <input type="text" class="form-control" id="mail" name="mail" value="<?php /*echo $name*/;?>" placeholder="enter your email">
		                    </div>
		                    <div class="form-group col-lg-12">
		                        <input type="text" class="form-control" id="name" name="name" value="<?php /*echo $name*/;?>" placeholder="ward">
		                    </div>
		                    <div class="form-group col-lg-12">
		                        <input type="text" class="form-control" id="name" name="name" value="<?php /*echo $name*/;?>" placeholder="estate">
		                    </div>
		                    <div class="form-group col-lg-6">
		                        <input type="password" class="form-control" id="pw" name="password" placeholder="choose a password">
		                    </div>
		                    <div class="form-group col-lg-6">
		                        <input type="password" class="form-control" id="pw" name="password" placeholder="confirm password">
		                    </div>
		                    <div class="form-group">
		                        <button type="submit" class="btn btn-sm" name="login" style="color: white;background-color: #5255de; margin-left: 40%">Get started</button>
		                    </div>           
		                </form>   
		               
		               <p class="text-center"><label> Already signed up? Login<a href="login.php" class=""> here</a></label></p>
		            </div>

		            <div class="col-lg-6">
		                <div class="thumbnail">
		                    <img src="images/Signup.png" alt="image not found">
		                    <div class="caption">
		                    	<h4 class="text-center"><label>Every single drop counts!</label></h4>
		                    </div>
		                </div>
		            </div>

		        </div>
		    </div>
		</div>
        <?php
            include("footer.php");
            ?>

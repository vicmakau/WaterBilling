<?php
	include("header.php");
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12" id="welcome">
				<div class="col-lg-12">
					<h2 class="text-center">Nice! Now Let's Pay Your Water Bill</h2>
				</div>
				<div class="col-lg-12">
					<h4 class="text-center">Just follow these three simple steps:</h4>
				</div>
				<div class="col-lg-12">
					<div class="col-lg-5">
					</div>
					<div class="col-lg-4">
						<ol>
							<li>Read your meter</li>
							<li>Calculate your bill</li>
							<li>Pay your bill</li>
						</ol>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="progress">
 						<div class="progress-bar" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width:10%">
						</div>
					</div> 
					<label>You are 10% done</label>
				</div>
				<div class="col-lg-12">
					<div class="col-lg-5">
					</div>
					<div class="col-lg-4">
						<a href="read.php"><button class="btn btn-lg btn-primary">Let's Get Started <span class="glyphicon glyphicon-arrow-right"></span></button></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	 <?php
            include("footer.php");
            ?>


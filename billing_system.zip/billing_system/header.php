
<!DOCTYPE html>
<html>
<head>
	<title>Water billing | secure and convenient</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../assets/jquery-3.3.1.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--for social media icons-->
	<link rel="icon" type="image/jpeg" href="images/icon.jpeg">

	<link href='https://fonts.googleapis.com/css?family=Amiri' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Hind Madurai' rel='stylesheet'>

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<style>
		body{
			font-family: 'Hind Madurai';
			font-size: 15px;
		}
		.jumbotron{
			font-family: 'Raleway';
			padding-top: 20px;
		}
		.jumbotron a button{
			border:1px solid white;
			background-color: inherit;
			color: white;
		}
		.jumbotron button:hover{
			color: white;
			border:2px solid white;
		}
		.navbar{
			background-color:  #f1f2f8;
			color: rgb(255,255,255);
			font-family: 'Hind Madurai';
		}
		.navbar li a:hover{
			text-decoration: underline;
			background-color: inherit;
			font-weight: bolder;
			color: #C70039;
		}
		#about li a{
			color: #C70039;
			font-size: 18px;
		}
		#about h3{
			color: #C70039;
			text-decoration: underline;
		}
		.ad h3{
			color: #C70039;
			font-family: 'Merriweather';
		}
		#features h3{
			color: #C70039;
		}
		#calculator h3{
			color: #C70039;
		}
		#calculator button{
			background-color:#C70039;
			color: white; 
		}
		footer{
			background-image: url('images/footer.jpg');
			color: rgb(255,255,255);
			background-repeat: no-repeat;
			background-position: ;
			background-size: auto;
		}
		footer a{
			color: white;
		}
		#social-signup li a span{
			padding: 30px;

		}
		#social-login li a span{
			padding: 30px;

		}
		#signup,#login p label{
			padding: 10px;
		}
		#account,#log .thumbnail{
			border:0px;
			border-radius: 5px;
		}
		#welcome div{
			padding: 10px;
		}
		#welcome ol li{
			padding: 10px;
		}
		#mpesa_pay ol li{
			padding: 5px;
		}
	</style>
</head>
<body>
	<div class="page-header">
		<div class="navbar navbar-fixed-top">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynav">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

					<a class="navbar-brand" href="index.php"><span class="glyphicon glyphicon-home"></span></a>

				</div>

				<div class="collapse navbar-collapse" id="mynav">
					<ul class="nav navbar-nav navbar-lg">
						<li><a href="#">HOME</a></li>
						<li><a href="#">ABOUT US</a></li>
						<li><a href="#">FEATURES</a></li>
						<li><a href="#">AWARDS</a></li>
						<li><a href="#">HELP</a></li>
					</ul>
					
					<ul class="nav navbar-nav navbar-right">
					
<!-- if logged in,display 'myaccount' else 'signup'
 -->						
						<?php
							if(isset($_SESSION["customer_name"])){
						?>
								<li><a href="myaccount.php"><span class="glyphicon glyphicon-user"> <?php echo $_SESSION['customer_name']; ?></span></a></li>
						<?php
							}
							else
							{
						?>
								<li><a href="signup.php"><span class="glyphicon glyphicon-user"> Signup</span></a></li>
						<?php
							}

						?>


<!-- if logged in,display 'logout' and vice versa
 -->
						<?php
						
							if(isset($_SESSION["customer_name"])){

						?>
								<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"> Logout</span></a></li>
						<?php

							}
							else
							{
						?>
								<li><a href="login.php"><span class="glyphicon glyphicon-log-in"> Login</span></a></li>
						<?php

							}

						?>
					</ul>
				</div><!-- navbar collapse -->
			</div><!-- container fluid -->
		</div> <!-- navbar --> 
	</div><!-- page-header -->